print(5 + 4 - 7 + 3)
