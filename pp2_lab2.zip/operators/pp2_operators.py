print(10 + 5)


print(5 + 4 - 7 + 3)
