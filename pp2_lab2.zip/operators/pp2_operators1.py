print(10 + 5)
