print(100 + 5 * 3)
