newlist = ['hello' for x in fruits]
