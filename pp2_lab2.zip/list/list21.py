thislist = ["apple", "banana", "cherry"]
thislist.insert(1, "orange")
print(thislist)
