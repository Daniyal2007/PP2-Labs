newlist = [x.upper() for x in fruits]
