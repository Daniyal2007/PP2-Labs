thislist = list(("apple", "banana", "cherry")) # note the double round-brackets
print(thislist)
