thislist = ["apple", "banana", "cherry"]
print(thislist[1])
