thislist = ["apple", "banana", "cherry"]
thislist.remove("banana")
print(thislist)
