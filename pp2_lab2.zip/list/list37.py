newlist = [x for x in fruits if x != "apple"]
