newlist = [x for x in fruits]
