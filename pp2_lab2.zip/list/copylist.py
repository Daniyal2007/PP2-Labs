thislist = ["apple", "banana", "cherry"]
mylist = thislist.copy()
print(mylist)




thislist = ["apple", "banana", "cherry"]
mylist = list(thislist)
print(mylist)





thislist = ["apple", "banana", "cherry"]
mylist = thislist[:]
print(mylist)
