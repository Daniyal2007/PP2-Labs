thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist)
