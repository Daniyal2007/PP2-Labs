newlist = [x if x != "banana" else "orange" for x in fruits]
