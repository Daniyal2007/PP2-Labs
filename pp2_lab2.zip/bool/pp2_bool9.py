def myFunction() :
  return True

if myFunction():
  print("YES!")
else:
  print("NO!")
