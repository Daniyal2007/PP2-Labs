thistuple = ("apple", "banana", "cherry")
for x in thistuple:
  print(x)






thistuple = ("apple", "banana", "cherry")
for i in range(len(thistuple)):
  print(thistuple[i])




thistuple = ("apple", "banana", "cherry")
i = 0
while i < len(thistuple):
  print(thistuple[i])
  i = i + 1
